mod {
    web_layout {
        BackendLayouts {
            1 {
                title = LLL:EXT:dr_starter/Resources/Private/Language/locallang_db.xlf:tx_drstarter_be_layout.pagets__1
                config {
					backend_layout {
							colCount = 4
							rowCount = 2
							rows {
								1 {
									columns {
										1 {
											name = Oben
											colPos = 0
											colspan = 4
										}
									}
								}
								2 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
										}
										2 {
											name = Mittlere Spalte
											colPos = 2
											colspan = 2
										}
										3 {
											name = Rechte Spalte
											colPos = 3
										}
									}
								}
							}
					}
                }
                icon = EXT:dr_starter/Resources/Public/Img/Backend/layout_3_cols_large.png
            }
            
            2 {
                title = LLL:EXT:dr_starter/Resources/Private/Language/locallang_db.xlf:tx_drstarter_be_layout.pagets__2
                config {
					backend_layout {
							colCount = 3
							rowCount = 2
							rows {
								1 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
											rowspan = 2
										}
										2 {
											name = Oben
											colPos = 0
											colspan = 2
										}
									}
								}
								2 {
									columns {
										1 {
											name = Mittlere Spalte
											colPos = 2
										}
										2 {
											name = Rechte Spalte 
											colPos = 3
										}
									}
								}
							}
					}
                }
                icon = EXT:dr_starter/Resources/Public/Img/Backend/layout_2_cols_right.png
            }
            
            3 {
                title = LLL:EXT:dr_starter/Resources/Private/Language/locallang_db.xlf:tx_drstarter_be_layout.pagets__3
                config {
					backend_layout {
							colCount = 3
							rowCount = 2
							rows {
								1 {
									columns {
										1 {
											name = Oben
											colPos = 0
											colspan = 2
										}
										2 {
											name = Rechte Spalte
											colPos = 3
											rowspan = 2
										}
									}
								}
								2 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
										}
										2 {
											name = Mittlere Spalte
											colPos = 2
										}
									}
								}
							}
					}
                }
                icon = EXT:dr_starter/Resources/Public/Img/Backend/layout_2_cols_left.png
            }
             
            4 {
                title = LLL:EXT:dr_starter/Resources/Private/Language/locallang_db.xlf:tx_drstarter_be_layout.pagets__4
                config {
					backend_layout {
							colCount = 2
							rowCount = 3
							rows {
								1 {
									columns {
										1 {
											name = Oben
											colPos = 0
											colspan = 2
										}
									}
								}
								2 {
									columns {
										1 {
											name = Linke Spalte
											colPos = 1
										}
										2 {
											name = Rechte Spalte
											colPos = 3
										}
									}
								}
								3 {
									columns {
										1 {
											name = Mittlere Spalte
											colPos = 2
											colspan = 2
										}
									}
								}
							}
					}
                }
                icon = EXT:dr_starter/Resources/Public/Img/Backend/layout_4_cols.png
            }
           
            5 {
                title = LLL:EXT:dr_starter/Resources/Private/Language/locallang_db.xlf:tx_drstarter_be_layout.pagets__5
                config {
						backend_layout {
								colCount = 1
								rowCount = 1
								rows {
										1 {
											columns {
												1 {
													name = Inhalt (ohne Menue)
													colPos = 0
												}
											}
										}
								}
						}
                }
                icon = EXT:dr_starter/Resources/Public/Img/Backend/layout_1_column.png
            }
            
        }
    }
}
