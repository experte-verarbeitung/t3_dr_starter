## + navigation.ts

## lib.navigation_top
## lib.navigation_sub
## lib.navigation_full
## lib.breadcrumb

lib.navigation_top = HMENU
lib.navigation_top.wrap = <nav class="navigation_top">|</nav>
lib.navigation_top {
            ### Erste Ebene ###
            1 = TMENU
            1 {
                wrap = <ul class="menu">|</ul>
                expAll = 1
                NO.wrapItemAndSub = <li class="menuitem normal">|</li> 
                NO.ATagParams.cObject = COA
                NO.ATagParams.cObject.10 = TEXT
                ACT < .NO
                ACT = 1
                ACT.ATagParams.cObject.10.value = onfocus="this.blur()"
                ACT.wrapItemAndSub = <li class="menuitem selected">|</li>
                ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
            }
}


## lib.navigation_sub
lib.navigation_sub = HMENU
lib.navigation_sub {
        wrap = <nav class="navigation_sub">|</nav>
        includeNotInMenu = 0
        entryLevel = 1
        1 = TMENU
        1 {
                expAll = 0
                wrap = <ul class="menu menu_1">|</ul>
                
                NO.wrapItemAndSub = <li class="menuitem normal">|</li>
                NO.ATagParams.cObject = COA
                NO.ATagParams.cObject.10 = TEXT
                NO.ATagParams.cObject.10.value = onfocus="this.blur()"
                
                ACT < .NO
                ACT = 1
                ACT = wrapItemAndSub = <li class="menuitem selected">|</li>
                ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
                
                CUR < .NO
                CUR = 1
                CUR.wrapItemAndSub = <li class="menuitem current">|</li>
                CUR.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
            
        }
        2 = TMENU
        2 {
            expAll = 0
                wrap = <ul class="menu menu_2">|</ul>
                NO.wrapItemAndSub = <li class="menuitem normal">|</li>
                ACT < .NO
                ACT.wrapItemAndSub = <li class="menuitem selected">|</li>
                ACT = 1
                CUR < .NO
                CUR.wrapItemAndSub = <li class="menuitem currrent">|</li>
                CUR = 1
        }

}

## lib.navigation_full
lib.navigation_full = HMENU
lib.navigation_full {
            wrap = <nav class="navigation_full">|</nav>
            includeNotInMenu = 0
            ### Erste Ebene ###
            1 = TMENU
            1 {
                entryLevel = 0
                wrap = <ul class="menu">|</ul>
                expAll = 1
                
                NO.wrapItemAndSub = <li class="menuitem normal">|</li> 
                NO.ATagParams.cObject = COA
                NO.ATagParams.cObject.10 = TEXT
                NO.ATagParams.cObject.10.value = onfocus="this.blur()"
                NO = 1
                
                ACT < .NO
                ACT = 1
                ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
                ACT.wrapItemAndSub = <li class="menuitem selected">|</li>
                
                CUR < .ACT
                CUR.wrapItemAndSub = <li class="menuitem current">|</li>
                CUR.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
            }
            ### weitere Ebenen ###
            2 < .1
            2.entryLevel = 1
            3 < .2
            3.entryLevel = 2
            4 < .2
            4.entryLevel = 3
}

# lib.breadcrumb
lib.breadcrumb = COA
lib.breadcrumb {
10 = HMENU
10 {
 special = rootline
 special.range = 0|-1
 1 = TMENU
     # no unneccessary scripting.
     1.noBlur = 1
     # Current item should be unlinked
     1.CUR = 1
     1.target = _self
     1.wrap = <div class="breadcrumb"> | </div>
     1.NO {
         stdWrap.field = title
         ATagTitle.field = nav_title // title
         linkWrap = ||*| >> |*|
         }
     # Current menu item is unlinked
     1.CUR {
         stdWrap.field = title
         linkWrap = ||*| >> |*|
         doNotLinkIt = 1
         }
    }
}

plugin.tx_dr_starter._CSS_DEFAULT_STYLE (

    /* navigation  */
    nav.navigation_top UL,
    nav.navigation_sub UL {
        margin:0;
        padding:0;
    }

    nav.navigation_sub UL li.menuitem A {
        text-decoration:none;
    }

    nav.navigation_sub UL.menu_1 li.menuitem A,
    nav.navigation_sub UL.menu_2 li.menuitem A,
    nav.navigation_sub UL.menu_3 li.menuitem A {
        font-size:1.0em;
    }

    nav.navigation_top UL li.menuitem,
    nav.navigation_sub UL li.menuitem
    {
        display:inline;
        list-style:none;
    }
    
    nav.navigation_sub UL li.menuitem {
        font-size:1.5em;
    }
    nav.navigation_sub UL li.menuitem:after,
    nav.navigation_top UL li.menuitem:after {
            content:" | ";
    }
    nav.navigation_sub UL li.menuitem:last-of-type:after,
    nav.navigation_top UL li.menuitem:last-of-type:after {
            content:"";
    }
    
    .mob_pagetitle {
        display:none;
    }
    .pagetitle{
        display:block;
    }
    /* navigation end */
    
    /* Menu info  */
    nav.navigation_full UL {
        list-style:none;
    }
    nav.navigation_full > UL {
        padding-left:5px;
        margin-top:0;
    }
    nav.navigation_full UL > LI > UL {
        padding-left:12px;
    }
    
    .info_clicknavi {
        margin-left:0px;
        border-radius:3px;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
        width:auto;;
        z-index:10;
        position:absolute;
        background:#fff;
    }
    .info_clicknavi div {
        cursor: pointer;
        text-align:center;
    }
    nav.navigation_full {
        padding:15px 3px 1px 3px;
    }
    .info_clicknavi nav.navigation_full {
        margin-top:10px;
    }
    
    .info_username, 
    .info_clicknavi ,
    .info_upward {
        display:block;
        margin-left:-10px;
        cursor:pointer;
        display:none;
    }
    
    .info_username,
    .info_upward {
        text-align:center;
    }
    
    .breadcrumb {
        margin-top:5px;
    }
    
    /* Menu info end*/
    
    /*  Style Hamburger  */
    DIV.hamburger {
        cursor: pointer;
        width: auto;
        margin:-5px 0 0 10px;
        z-index:15;
        position:absolute;
    }
    .hamburger span {
        display: block;
        width: 20px;
        height: 4px;
        margin: 4px 0;
        background: rgb(0,0,0);
    }
    /*  Hamburger end */
    
    /* content sizes and position */
    #blank_container .grid_element {
        width:100%;
    }
    .third, .double, .half, .fifty {
        float:left;
    }
    
    .third {
        width:33.33%;
    }
    .third.padded {
        width:calc(33.33% - 4px);
    }
    
    .double {
        width:66%;
    }
    .double.padded {
        width:calc(66% - 2px);
    }
    
    .half, .fifty {
        width:50%;
    }
    .half.padded {
        width:calc(50% - 4px);
    }
    .fifty.padded {
        width:calc(50% - 4px);
    }
    .page-layout-0 .fifty.padded {
        width:50%;
        margin:0;
        border:0;
    }
    
    #container, #blank_container {
        max-width:{$plugin.dr_starter.settings.maxwidth}px;
        min-width:{$plugin.dr_starter.settings.minwidth}px;
    }
    #container DIV.inner_container, .drstarter_footer  {
        margin-left:{$plugin.dr_starter.settings.logowidth}px;
    }
    #navigation_container {
        margin-left:{$plugin.dr_starter.settings.logowidth}px;
        min-height:{$plugin.dr_starter.settings.logowidth}px;
    }
    #fixlogo_container , #homebut_container {
        width:{$plugin.dr_starter.settings.logowidth}px;
    }   
    #visible_img , #invisible_img , #homebut_container , info_clicknavi , info_upward {
        width:calc( {$plugin.dr_starter.settings.logowidth}px -11px );
    } 
    .grid_element {
        min-width:{$plugin.dr_starter.settings.minwidth}px;
    }

/* maxwidth = ca 1500 */
@media screen and ( max-width:calc( {$plugin.dr_starter.settings.maxwidth}px - 10px ) ) {

    
    DIV.be_layout_pagets__2 .third.pos-right {
        width:100%;
    }
        
        .info_clicknavi nav.navigation_full {
            margin-top:10px;
        }

        .grid_element.third.padded,
        .grid_element.half.padded,
        .grid_element.double.padded,
        .grid_element.fifty.padded { 
            width:calc(50% - 4px);
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }

        .grid_element.half,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.third { 
            width:50%;
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }

        #container DIV.inner_container, 
        #navigation_container, .drstarter_footer, 
        #homebut_container {
            margin-left:105px;
        }

        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:100px;
        }
}
    
/* 3 x min width = ca 900 */
@media screen and ( max-width:calc( 50px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px) ) {
        .mob_pagetitle {
            display:block;
        }
        .pagetitle{
            display:none;
        }
        .info_upward {
            display:block;
            margin-left:1px;
        }
       
        #container DIV.inner_container, .drstarter_footer ,
        #navigation_container, 
        #homebut_container {
            margin-left:55px;
        }

        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:50px;
        }
        
        .grid_element.third.padded,
        .grid_element.half.padded,
        .grid_element.double.padded,
        .grid_element.fifty.padded,
        .grid_element.third,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half {
            width:100%;
            min-width:calc( {$plugin.dr_starter.settings.minwidth}px );
        }
        .grid_element.mob_full {
            width:100%;
            min-width:calc( {$plugin.dr_starter.settings.minwidth}px );
        }
}
    
    /* 2 x min width = ca 600 */
    @media screen and ( max-width:calc( 50px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px ) ) {
        .grid_element,
        .grid_element.third,
        .grid_element.half,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half {
            width:100%;
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }
    }
    /* 1 x min width = ca 300 */
    @media screen and ( max-width:calc( 50px + {$plugin.dr_starter.settings.minwidth}px ) ) {
        .info_clicknavi,
        .info_upward {
            font-size:0.8em;
        }
        .grid_element,
        .grid_element.third,
        .grid_element.half,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half {
            width:100%;
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }
    }
)
