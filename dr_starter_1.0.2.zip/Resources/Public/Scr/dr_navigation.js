function fitStyleToWindowSize( breakpoint ) {
		viewportwidth = $(window).width();
		if (viewportwidth > breakpoint ) {
 			$('.info_clicknavi').fadeOut(0);
		}
}

$(document).ready(function(){
	fitStyleToWindowSize( 635 );
	window.onresize = function(event) { fitStyleToWindowSize( 635 ); }
   
    $('.info_upward').fadeOut(300);
    $('.info_username').fadeIn(300);

	$(function () {
		$(window).scroll(function () {
            // Wenn 150 Pixel gescrolled wurde
            var has_scrolled = $(this).scrollTop() > 150;
            if( has_scrolled == false ) displayMenu( has_scrolled );
		});
	});	
	
});

function displayMenu( show ) {
    if ( show ) { 
        $('.info_username').fadeOut(30);
        $('.info_upward').fadeIn(100);
        $('.info_clicknavi').fadeIn(80);
    } else {
        $('.info_upward').fadeOut(100);
        $('.info_clicknavi').fadeOut(80);
        $('.info_username').fadeIn(30);
    }
}

function anfang() {
	$("body,html").animate({
		scrollTop: 0,
		scrollLeft: 0
	}, 550);
}

function ende() {
	$("body,html").animate({
		scrollTop: $(document).height() + $(window).height(),
		scrollLeft: 8
	}, 550);
}


// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 
