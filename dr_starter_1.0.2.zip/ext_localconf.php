<?php
## Affored by extension sfgz_design
## instead to place this code in the actual document ext_localconf.php it could also be placed in typo3conf/ext/additionalConfiguration.php

$GLOBALS['TYPO3_CONF_VARS']['SYS']['locallangXMLOverride']['de']['EXT:frontend/Resources/Private/Language/locallang_ttc.xlf'][] = 'typo3conf/ext/dr_starter/Resources/Private/Language/frontend/de.locallang_ttc.xlf';
$GLOBALS['TYPO3_CONF_VARS']['SYS']['locallangXMLOverride']['de']['EXT:lang/Resources/Private/Language/locallang_general.xlf'][] = 'typo3conf/ext/dr_starter/Resources/Private/Language/lang/de.locallang_general.xlf';

# In file dr_starter/Configuration/PageTSConfig/:
$GLOBALS['TYPO3_CONF_VARS']['RTE']['Presets']['dr_full'] = 'EXT:dr_starter/Configuration/RTE/Full.yaml';

/**
 * Pre processors
 */
// Frontend Editing: Repair links when saving 
 $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['FrontendEditing']['requestPreProcess'][] = \Sfgz\SfgzDesign\Hook\PreProcessFeEdit::class;
?>
