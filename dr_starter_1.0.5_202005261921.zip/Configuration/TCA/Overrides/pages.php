<?php
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/TSconfig_all.txt',
        'Eigener Style, alle überflüssige Eingabefelder ausblenden.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_defaults.txt',
        'nur Eigener Style, Listen und Beschriftungen.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_meta.txt',
        'nur Metadaten, Sprache, Kategorien und Hinweise ausblenden.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_date.txt',
        'nur Ablaufdatum und Cache-verhalten ausblenden.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_admin.txt',
        'nur Admin Felder ausblenden.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_title.txt',
        'nur Titel vereinfachen in Inhalte und Seite.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_users.txt',
        'nur Users: Persönliche Daten und Hinweise ausblenden.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_motion.txt',
        'nur Ändernde Bilder im Header ausblenden. pages'
);

