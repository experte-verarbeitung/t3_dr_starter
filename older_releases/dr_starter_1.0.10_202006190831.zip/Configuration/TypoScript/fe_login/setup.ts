plugin.tx_felogin_pi1 {
    email_from = daten@sfgz.ch
    replyTo = daten@sfgz.ch
}
plugin.tx_felogin_pix._CSS_DEFAULT_STYLE (
    .tx-felogin-pi1 FORM DIV {display:block;padding:0;margin:0;}
    .tx-felogin-pi1 FORM > FIELDSET > DIV {margin:8px 0;}
    .sidebox .tx-felogin-pi1 {padding:4px;background:#FFF;border-radius:4px;}
    .tx-felogin-pi1 p {padding:0;margin:0;}
    .tx-felogin-pi1 p a {font-size:100%;text-decoration:none;color:#009ee0;font-weight:bold;}
    .tx-felogin-pi1 p a:hover {color:#009ee0;text-decoration:underline;opacity:0.8;}
    .tx-felogin-pi1 form div {width:auto;margin:0;}
    .tx-felogin-pi1 legend {display:none;}
    .frame-type-login H2 {font-family: SFGZSansBlack, Helvetica, Arial, sans-serif;}
    .tx-felogin-pi1 H3 {font-size: 27px;font-family: SFGZSansBlack, Helvetica, Arial, sans-serif;}
    .frame-layout-4 .tx-felogin-pi1 H3 {display:none;}
    .tx-felogin-pi1 fieldset {border:0;padding:0;margin:0;}
    .tx-felogin-pi1 label {display:block;font-size:11pt;margin:0px;padding-top:3px;color:#999;}
    .tx-felogin-pi1 label[for=user] {float:left;width:8em;}
    .tx-felogin-pi1 label[for=pass] {float:left;width:8em;}
    .tx-felogin-pi1 label[for=permalogin] {display:inline;}
    .tx-felogin-pi1 label[for=tx_drfblogin_id] {width:8em;}
    .tx-felogin-pi1 label[for=tx_drfblogin_autologin] {float:left;width:auto;}
    .tx-felogin-pi1 input {font-size:smaller;}
    .tx-felogin-pi1 input[name=submit] {font-size:smaller;margin-top:5px;}
    .tx-felogin-pi1 #user {width:9.5em;margin:0;}
    .tx-felogin-pi1 #pass {width:9.5em;margin:0;}
    .tx-felogin-pi1 #permalogin {margin:0;}
    TABLE.tx-felogin-pi1  {width:338px;padding:0;margin:0;white-space:normal;}
    DIV.tx-felogin-pi1  {padding:0px;margin:0;white-space:normal;}
    .tx-felogin-pi1 label {color:black;}
    .tx-felogin-pi1 fieldset {margin:10px 0;}
)
