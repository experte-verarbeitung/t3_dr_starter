# customcategory=dr_dstarter=DR Starter
# customsubcategory=a_grund=Pfad zur Website
# customsubcategory=bb_titles=Titlei
# customsubcategory=bc_fonts=Fonts
# customsubcategory=bd_design=Design
# customsubcategory=c_special2Content=Spezielle Inhalte
# customsubcategory=d_javascript=JavaScript und Entwicklung

plugin.dr_starter {
    settings {
        # cat=dr_dstarter/a_grund/a; type=text; label=baseURL:Basis URL mit Protokoll zB. http://my.example.com/path2typo3/
        baseURL = https://polygrafie.sfgz.ch/datenbanken/
        # cat=dr_dstarter/a_grund/b; type=text; label=absRefPrefix:Wenn gesetzt, wird der Pfadteil allen mit TypoScript erzeugten Links vorangestellt. Z.B.:  /path2typo3/
        absRefPrefix = /datenbanken/
        # cat=dr_dstarter/bb_titles/12; type=text; label=Browser-Titel:Website-Titel im Rahmen des Browsers.
        browsertitle = Colormixture
        # cat=dr_dstarter/bb_titles/14; type=text; label=Website-Titel:Website-Titel auf Seite.
        sitetitle = Colormixture - Farbmischung
        # cat=dr_dstarter/bb_titles/16; type=text; label=Small Dev Website-Titel:Website-Titel auf Smartphone Seite.
        siteshorttitle = Colormixture
        # cat=dr_dstarter/bb_titles/18; type=text; label=Website-Subtitel:Kleiner Subtitel neben Website-Titel auf Seite.
        sitesubtitle = Additive und Subtraktiv
        # cat=dr_dstarter/bc_fonts/10; type=options[Helvetica,Antaro,Cloudy,Comics,ParaType]; label= Schriftfamilie Titel:Haupttitel, Titel im Text, sichtbare Navigation.
        font_title = Cloudy
        # cat=dr_dstarter/bc_fonts/20; type=options[Helvetica,Antaro,Cloudy,Comics,ParaType]; label= Schriftfamilie Seiten Sub-Titel
        font_subheader = Comics
        # cat=dr_dstarter/bc_fonts/30; type=options[Helvetica,Antaro,Cloudy,Comics,ParaType]; label= Schriftfamilie Inhalt 
        font_content = Comics
        # cat=dr_dstarter/bc_fonts/40; type=options[Helvetica,Antaro,Cloudy,Comics,ParaType]; label= Schriftfamilie Info und versteckte Navigation
        font_infos = Helvetica
        
        # cat=dr_dstarter/bd_design/10; type=int; label=Maximale Breite:Maximale Breite der Website
        maxwidth = 1500
        # cat=dr_dstarter/bd_design/20; type=int; label=Minimale Breite:Minimale Breite der Website
        minwidth = 300
        # cat=dr_dstarter/bd_design/30; type=int; label=Kopfzeile Höhe:Die Höhe der Mobile-Navigation in grossen Displays
        headerheight = 100
        # cat=dr_dstarter/bd_design/40; type=int; label=Logo Breite:Breite des logos in Pixel
        logowidth = 184
        # cat=dr_dstarter/bd_design/50; type=string; label=Logo Pfad:Pfad wie zB. /typo3conf/ext/dr_starter/Resources/Public/Img/Web/logo.png
        logopath = /typo3conf/ext/dr_starter/Resources/Public/Img/Web/logo.png
        # cat=dr_dstarter/bd_design/60; type=string; label=Favicon Pfad:Pfad wie zB. /typo3conf/ext/dr_starter/Resources/Public/Img/Web/favicon.ico
        faviconpath = /typo3conf/ext/dr_starter/Resources/Public/Img/Web/favicon.ico
        
        # cat=dr_dstarter/c_special2Content/6; type=int; label=permacontent:Uid des Content Elements in der Sidebar.
        permacontent = 0
        # cat=dr_dstarter/c_special2Content/7; type=int; label=CSS content:Uid des Content Elements mit CSS Code für Header.
        css_content = 0
        # cat=dr_dstarter/c_special2Content/8; type=int; label=Js Content:Uid des Content Elements mit JS Code für Header.
        js_content = 0
        
        # cat=dr_dstarter/d_javascript/1; type=boolean; label=JQuery laden: Markierung aufheben wenn JQuery anderweitig geladen wird
        loadjquery=1
        # cat=dr_dstarter/d_javascript/2; type=boolean; label=Debug:Zeigt Layout-Informationen im Footer
        debug = 0
    }
}


