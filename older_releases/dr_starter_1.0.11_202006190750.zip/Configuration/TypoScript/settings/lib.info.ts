## + lib.info.ts

## contains:
## lib.info_baseURL
## lib.info_pagelayout
## lib.info_backend_layout
## lib.logopath

## lib.info_sitetitle_web info_sitetitle_web
## lib.info_sitetitle_mob info_sitetitle_mob
## lib.info_pagetitle info_pagetitle
## lib.info_titles_screen info_titles_screen
## lib.info_titles_print info_titles_print
## lib.info_subtitle info_titles_screen

lib.logopath = TEXT
lib.logopath.insertData = 1
lib.logopath.value = {$plugin.dr_starter.settings.logopath}

lib.info_baseURL = TEXT
lib.info_baseURL.insertData = 1
lib.info_baseURL.value = {$plugin.dr_starter.settings.baseURL}

lib.info_debug = TEXT
lib.info_debug.insertData = 1
lib.info_debug.value = {$plugin.dr_starter.settings.debug}

lib.info_datum = TEXT
lib.info_datum.insertData = 1
lib.info_datum {
        data = date:U
        strftime = %d-%m-%Y
}

lib.info_unixzeit = TEXT
lib.info_unixzeit.insertData = 1
lib.info_unixzeit {
        insertData = 1
        data = date:U
}

## info_pagelayout
lib.info_pagelayout = TEXT
lib.info_pagelayout.insertData = 1
lib.info_pagelayout.value = {page:layout}

## info_backend_layout
lib.info_backend_layout = TEXT
lib.info_backend_layout.insertData = 1
lib.info_backend_layout.value = {page:backend_layout}


## lib.info_sitetitle_web
lib.info_sitetitle_web = COA_INT
lib.info_sitetitle_web {
    stdWrap.wrap = <H1 class="web_pagetitle">|</H1>
    10 = TEXT
    10 {
        insertData = 1
        wrap = | 
        value = {$plugin.dr_starter.settings.sitetitle}
    }
    20 < .10
    20 {
        noTrimWrap = | <span> | </span> |
        value = {$plugin.dr_starter.settings.sitesubtitle}
    }
}

## lib.info_sitetitle_mob
lib.info_sitetitle_mob < lib.info_sitetitle_web
lib.info_sitetitle_mob.10.value = {$plugin.dr_starter.settings.siteshorttitle}
lib.info_sitetitle_mob.stdWrap.wrap = <H1 class="mob_pagetitle">|</H1>
lib.info_sitetitle_mob.20 >
lib.info_sitetitle = COA_INT
lib.info_sitetitle.10 < lib.info_sitetitle_web
lib.info_sitetitle.20 < lib.info_sitetitle_mob

## info_pagetitle
lib.info_pagetitle = COA_INT
lib.info_pagetitle {
	wrap = <H2 class="info_pagetitle page-title ">|</H2>
    10 = TEXT
	10.insertData = 1
	10.data = page:title
}


## info_subtitle
lib.info_subtitle = COA_INT
lib.info_subtitle {
    # wenn kein subtitle dann anders wrappen
    wrap = <div class="info_titles_screen screen"><H1>|</H1></div>
    wrap.override.if.isFalse.data = page:subtitle
    wrap.override = |
    # aktueller Seiten-Untertitel aus Tabelle page
    15 = TEXT
    15 {
        insertData = 1
        value = {page:subtitle}
        wrap = |
    }
}

## Title info_titles_print
lib.info_titles_print = COA
lib.info_titles_print {
    
    wrap = <div class="print info_titles_print"><H1>|</H1></div>
    
    5 = TEXT
    5 {
        value = {$plugin.dr_starter.settings.sitetitle}
    }
    
    10 = TEXT
    10 {
        value = {$plugin.dr_starter.settings.sitesubtitle}
        noTrimWrap = |<span class="smallhint"> |</span>|
    }
    
}
plugin.tx_dr_starter_lib._CSS_DEFAULT_STYLE (/* NAVIGATION */
    /* Special for Page-Titles */
    #navigation_container H2.info_pagetitle.page-title {
        margin:8px 0 5px 0;
    }
    #navigation_container H1.web_pagetitle {
        margin:20px 0 5px 0;
    }
    
    .breadcrumb { margin:0; float:left;width:auto;}
    .breadcrumb span { padding:0 2px; }
    nav.navigation_sub { margin:0;padding:0; } 
    nav.navigation_sub:last-of-type { margin:0; }
    
    nav.navigation_top UL {
        margin:0;
        padding:0;
        font-size:1.3em;
    }
    
    nav.navigation_sub UL { 
        margin:0;
        padding:0; 
        border-radius:15px;  
        border:thin solid #888;
        border-color:#eee #ddd #555 #888;
        font-size:1.2em;
        border:0;
        font-size:1.3em;
    }
    
    .navigation_top A, .navigation_top A:link, .navigation_top a:visited , .navigation_top A:hover , .navigation_top A.selected ,
    .navigation_sub A, .navigation_sub A:link, .navigation_sub a:visited , .navigation_sub A:hover , .navigation_sub A.selected ,
    .drstarter_footer A, .drstarter_footer A:link, .drstarter_footer a:visited , .drstarter_footer A:hover , .drstarter_footer A.selected 
    { 
        text-decoration:none;
        margin:0;
        padding:0; 
    }

    nav.navigation_sub UL li.menuitem A { text-decoration:none; }

/*
    nav.navigation_sub UL.menu_1 li.menuitem A { font-size:1.0em; }
    nav.navigation_sub UL.menu_2 li.menuitem A { font-size:0.90em; }
    nav.navigation_sub UL.menu_3 li.menuitem A { font-size:0.92em; }
    nav.navigation_sub UL.menu_4 li.menuitem A { font-size:0.87em; }
*/
/*
    nav.navigation_sub UL.menu_1 { margin-left:0px; }
    nav.navigation_sub UL.menu_2 { margin-left:15px; }
    nav.navigation_sub UL.menu_3 { margin-left:30px; }
    nav.navigation_sub UL.menu_4 { margin-left:45px; }
*/

    nav.navigation_top UL li.menuitem,
    nav.navigation_sub UL li.menuitem
    {
        display:inline;
        list-style:none;
    }
    nav.navigation_sub UL li.menuitem:after,
    nav.navigation_top UL li.menuitem:after {
            content:" | ";
    }
    nav.navigation_sub UL li.menuitem:last-of-type:after,
    nav.navigation_top UL li.menuitem:last-of-type:after {
            content:"";
    }
    nav.navigation_sub UL li.menuitem.has_sub:after { 
        content:'↓ | ';
    }
    
    /* navigation end 
    
    /* Menu info  */
    nav.navigation_full UL { list-style:none; }
    nav.navigation_full > UL {
        padding-left:0px;
        margin-top:0;
    }
    nav.navigation_full UL > LI > UL { padding-left:12px; }
    nav.navigation_full { padding:15px 3px 1px 3px;  }
    
    .info_clicknavi {
        margin:-35px 0px 0px 0px;
        padding:20px 12px 0px 5px;
        border-radius:3px;
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
        width:auto;;
        z-index:10;
        position:absolute;
        background:#fff;
        display:none;
    }
    
    .info_clicknavi nav.navigation_full {
        margin:0px;
        margin:0px;
    }
    .info_clicknavi nav.navigation_full A, .info_clicknavi nav.navigation_full A:link {
        text-decoration:none;
        border:0;
        padding-bottom:0;
        margin-bottom:0;
    }
    
    /* Menu info end*/
    
    /*  Style Hamburger  */
    DIV.hamburger {
        cursor: pointer;
        margin:-5px 0 5px 10px;
        z-index:15;
        position:relative;
        width:100%;
    }
    .hamburger span {
        display: block;
        width: 20px;
        height: 4px;
        margin: 4px 0;
        background: rgb(0,0,0);
    }
    /*  Hamburger end */
    
)
