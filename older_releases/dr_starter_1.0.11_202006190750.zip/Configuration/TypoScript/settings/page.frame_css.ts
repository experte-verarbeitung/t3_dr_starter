plugin.tx_dr_starter_css._CSS_DEFAULT_STYLE (
/* special tt_contens as defined in TSconfig_tt.txt */
/* Font-sizes for tt_content.layout */
    .frame-layout-0 { font-size:1; }
    .frame-layout-1 { font-size:0.8em; }
    .frame-layout-2 { font-size:1.3em; }
    .frame-layout-3 { font-size:1.05em; }
    /* 3 titles + content font-family */
    .frame-layout-3, .frame-layout-3 H1, .frame-layout-3 H2, .frame-layout-3 H3, .frame-layout-3 H4, .frame-layout-3 H5 {
        font-family: "Helvetica Neue" , Helvetica , Arial, sans-serif;
    }
    .frame-layout-4 { 
        font-size:1em; 
        font-family: Antaro , "Helvetica Neue" , Helvetica , Arial, sans-serif;
    }
    /* 4 titles */
    .frame-layout-4 H1, .frame-layout-4 H2, .frame-layout-4 H3, .frame-layout-4 H4, .frame-layout-4 H5 {
        font-family: Comics , "Helvetica Neue" , Helvetica , Arial, sans-serif;
    }
    
    .frame-links-fliessend { 
        float:left;  
        /* Firefox */
        width: -moz-calc(33% - 17px);
        /* WebKit */
        width: -webkit-calc(33% - 17px);
        /* Opera */
        width: -o-calc(33% - 17px);
        /* Standard */
        width: calc(33% - 17px);	
        margin-right:17px;
                
    }
    .frame-links-fliessend-66 { 
        float:left;  
        /* Firefox */
        width: -moz-calc(65% - 17px);
        /* WebKit */
        width: -webkit-calc(65% - 17px);
        /* Opera */
        width: -o-calc(65% - 17px);
        /* Standard */
        width: calc(65% - 17px);	
        margin-right:17px;	
    }

    .frame-links-fliessend-auto { 
        float:left;  
        width: auto;	
        margin-right:0.3rem;
    }
    DIV.frame-links-fliessend-auto:last-of-type { 
        margin-right:0px;
    }
    
    .frame-rechts-fliessend { float:right; width:auto; }
    .frame-ende-fliessend { clear:both; }

    /*  tt_content menue */
    DIV.grid_element  div.frame-type-menu_section UL , DIV.grid_element  div.frame-type-menu_section_pages UL { 
        list-style-type:none; 
    }
    DIV.grid_element  div.frame-type-menu_section UL A , DIV.grid_element  div.frame-type-menu_section_pages UL A { 
        text-decoration:none;
        border:0;
    }
/*  tt_content sitemap */
    DIV.grid_element  .frame-type-menu_sitemap A, DIV.grid_element  .frame-type-menu_sitemap A:link {
        text-decoration:none;
        border:0;
        padding-bottom:0;
        margin-bottom:0;
    }
    DIV.grid_element  .frame-type-menu_sitemap > UL {
        padding:0px;
        margin:0;
    }
    .frame-type-menu_sitemap UL UL,
    .frame-type-menu_sitemap UL UL UL,
    .frame-type-menu_sitemap UL UL UL UL {
        padding-left:15px;
    }
    .frame-type-menu_sitemap LI,
    .frame-type-menu_sitemap UL {
        list-style:none;
    }

/* end special tt_contens ( CSS-Styled content) */
/*  Position main-frames, logo-frame and Contents  */
    #container, #blank_container {
        margin:5px auto;
    }
    #homebut_container {
        position:absolute;
        z-index:4;
        margin:0px;
        padding:0px;
        opacity:0.2;
    }
    #fixlogo_container { 
        position:fixed; 
        z-index:3;
        margin:0px;
        padding:0px;
    }
    #visible_img {
        cursor:pointer; 
        margin:0;
        padding:0;
    }
    #invisible_img {
        margin:0;
        padding:0;
    }
    #visible_img , #invisible_img {
        border-radius:50% ;
    } 
    .inner_container {
        font-size:1.2em;
    }
    
    .drstarter_footer {
        border:thin solid black; 
        margin-top:10px;
        margin-bottom:25px;
        padding:3px 8px 0px 8px;
        border-radius:3px;
    }


    #header_container { 
        position:relative;
        z-index:2;
        top:0;
        width:100%;
        max-width:{$plugin.dr_starter.settings.maxwidth}px;
        min-width:{$plugin.dr_starter.settings.minwidth}px;
        background:#fff;
    }
    
    #container, #blank_container {
        max-width:{$plugin.dr_starter.settings.maxwidth}px;
        min-width:{$plugin.dr_starter.settings.minwidth}px;
    }
    #container DIV.inner_container, .drstarter_footer  {
        margin-left:{$plugin.dr_starter.settings.logowidth}px;
    }
    #navigation_container {
        margin-left:{$plugin.dr_starter.settings.logowidth}px;
    }
    #fixlogo_container {
        width:{$plugin.dr_starter.settings.logowidth}px;
    }   
    #visible_img , #invisible_img , #homebut_container , .info_clicknavi , .info_upward {
        width:calc( {$plugin.dr_starter.settings.logowidth}px - 11px );
    } 

/* Override font-families if given in plugin-constants from template. */
    #container, #blank_container {
        font-family: {$plugin.dr_starter.settings.font_content};
    }
    
    H1,H2,H3,H4,H5 , nav.navigation_top , nav.navigation_sub {
        font-family: {$plugin.dr_starter.settings.font_title};
    }
    
    .info_titles_screen H1 {
        font-family: {$plugin.dr_starter.settings.font_subheader};
        margin:0 0 3px 0;
        font-variant: small-caps;
        font-weight:normal;
        font-size:1.55em;
    }
    .grid_element {
        min-width:{$plugin.dr_starter.settings.minwidth}px;
    }

    #lightbox,  .drstarter_footer , #fixlogo_container {
        font-family: {$plugin.dr_starter.settings.font_infos};
    }
    
    .mob_pagetitle {
        display:none;
    }
    .web_pagetitle {
        display:block;
    }
    .web_pagetitle span {
        font-size:0.5em;
    }
    
    /* content sizes and position */
    
    .grid_element > P { margin:0 ;}
    .grid_element .frame > P { margin:0 ;}
    
    #blank_container .grid_element {
        width:100%;
    }
    .third, .double, .half, .fifty {
        float:left;
    }
    
    .third {
        width:33.33%;
    }
    .third.padded {
        width:calc(33.33% - 4px);
    }
    
    .double {
        width:66%;
    }
    .double.padded {
        width:calc(66% - 2px);
    }
    
    .half, .fifty {
        width:50%;
    }
    .half.padded {
        width:calc(50% - 4px);
    }
    .fifty.padded {
        width:calc(50% - 4px);
    }
    .page-layout-0 .fifty.padded {
        width:50%;
        margin:0;
        border:0;
    }
    
/* maxwidth default = 1500 , max-width:1040 */
@media screen and ( max-width:calc( 150px + {$plugin.dr_starter.settings.logowidth}px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px ) ) {
    
        DIV.be_layout_pagets__2 .third.pos-right {
            width:100%;
        }
        .grid_element.third.padded,
        .grid_element.half.padded,
        .grid_element.double.padded,
        .grid_element.fifty.padded { 
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }

        .grid_element.half,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.third { 
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }

        #container DIV.inner_container, 
        #navigation_container, .drstarter_footer {
            margin-left:105px;
        }

        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:100px;
        }
        
}
@media screen and ( max-width:calc( 1040px  ) ) {
        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:100px;
        }
        .grid_element.third.padded,
        .grid_element.half.padded,
        .grid_element.double.padded,
        .grid_element.fifty.padded,
        .grid_element.third,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half,
        .grid_element.mob_full {
            width:calc( 280px ); 
            min-width: 250px;
        }
}

/* minwidth default = 300 , max-width:1050 */
@media screen and ( max-width:calc( 150px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px) ) {
        /* #container DIV.inner_container,  #navigation_container, .drstarter_footer { background-color:white; } */
        
        .info_titles_screen H1 {
            font-size:1.3em;
        }
        
        .drstarter_footer  {
            margin-left:55px;
        }
        
        #header_container { 
            height:{$plugin.dr_starter.settings.headerheight}px; 
            position:fixed;
            border-bottom:1px solid black;
            left:0;
        }
        
        #navigation_container {
            position:fixed;
            z-index:2;
            width:100%;
            margin-left:55px;
        }

        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:50px;
        }
        
        #homebut_container,
        #fixlogo_container {
            margin-left:0px;
           background:white;
        }
        
        #container DIV.inner_container {
            margin:0;
            margin-top:{$plugin.dr_starter.settings.headerheight}px;
        }
        
        .mob_pagetitle {
            display:block;
        }
        .web_pagetitle , .navigation_top , .navigation_sub , .navigation_subtitle .info_titles_screen {
            display:none;
        }

        .grid_element.third.padded,
        .grid_element.half.padded,
        .grid_element.double.padded,
        .grid_element.fifty.padded,
        .grid_element.third,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half,
        .grid_element.mob_full {
            width:100%; 
            min-width: {$plugin.dr_starter.settings.minwidth}px;
        }
        
        #header_container #fixlogo_container .info_clicknavi nav.navigation_full{
            height:300px;
            overflow-y:scroll;
            margin-top:12px;
        }
}
/* minwidth default = 300 , max-width: 650 */
@media screen and ( max-width:calc( 100px + {$plugin.dr_starter.settings.minwidth}px ) ) {
        H1.mob_pagetitle {
            font-size:1.2em;
            margin:0;
        }
        H2.info_pagetitle {
            font-size:1.0em;
            margin:0;
        }
        
        #header_container { 
            height:calc({$plugin.dr_starter.settings.headerheight}px - 30px); 
        }
        
        #container DIV.inner_container {
            margin:0px;
            margin-top:calc({$plugin.dr_starter.settings.headerheight}px - 30px);
        }
        
        .drstarter_footer ,
        #homebut_container {
            margin-left:0px;
        }
        
        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:35px;
        }
}
)
