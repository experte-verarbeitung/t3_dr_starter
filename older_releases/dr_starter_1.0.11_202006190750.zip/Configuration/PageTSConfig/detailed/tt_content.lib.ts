
### Anker vor Content entfernen (automatischer a Tag)
# tt_content.stdWrap.dataWrap =
# tt_content.noANameTagForFirstRecord = 1 
# tt_content.stdWrap.prepend.dataWrap =

# static TEMPLATE 6.2 cObject for all
tt_content.stdWrap.innerWrap.cObject.default.20.stdWrap.noTrimWrap = | class="| layout-{field:layout}" |
tt_content.stdWrap.innerWrap.cObject.default.20.stdWrap.insertData = 1

# static TEMPLATE cObject for new
tt_content.stdWrap.innerWrap.cObject {
    1 =< tt_content.stdWrap.innerWrap.cObject.default
    1.20.10.value = csc-unsichtbar
    100 =< tt_content.stdWrap.innerWrap.cObject.default
    100.20.10.value = csc-wichtig
    101 =< tt_content.stdWrap.innerWrap.cObject.default
    101.20.10.value = csc-linksfliessend
    102 =< tt_content.stdWrap.innerWrap.cObject.default
    102.20.10.value = csc-rechtsfliessend
    103 =< tt_content.stdWrap.innerWrap.cObject.default
    103.20.10.value = csc-endefliessend
}


tt_content.stdWrap.innerWrap.cObject {
    10.15.value = csc-frame csc-frame-indent
    11.15.value = csc-frame csc-frame-indent3366
    12.15.value = csc-frame csc-frame-indent6633
    20.15.value = csc-frame csc-frame-frame1
    21.15.value = csc-frame csc-frame-frame2

    10.20.10.value = csc-frame csc-frame-indent
    11.20.10.value = csc-frame csc-frame-indent3366
    12.20.10.value = csc-frame csc-frame-indent6633
    20.20.10.value = csc-frame csc-frame-frame1
    21.20.10.value = csc-frame csc-frame-frame2
}
	
# Typo3 Layout Optionen Content-Elemente not used, use config above
# tt_content.stdWrap.innerWrap.cObject = CASE
# tt_content.stdWrap.innerWrap.cObject {
# 	key.field = layout
# 	0 = TEXT
# 	0.value = <div class="csc-default normalerText">|</div>
# 	1 = TEXT
# 	1.value = <div class="csc-default kleinerText">|</div>
# 	2 = TEXT
# 	2.value = <div class="csc-default grosserText">|</div>
# 	3 = TEXT
# 	3.value = <div class="csc-default riesigerText">|</div>
# }

    
# tt_content.stdWrap.innerWrap2 = |<a href="javascript:;" onclick="anfang();return false;">Seitenanfang</a>
# [globalVar = TSFE:type=95]
#    tt_content.stdWrap.innerWrap2 = |
# [global]
# new since 7.6.21: [tt_content][3][linkToTop]

# static TEMPLATE cObject for images
# tt_content.image.20.maxW = 950

# Zufallsinhalt von gewaehlter Seite
tt_content.menu.20.8 = COA_INT
tt_content.menu.20.8 {
  10 = CONTENT
  10 {
    table = tt_content
    select {
      pidInList.override.field = pages
      where = colPos=0
      max = 1
      orderBy = rand()
    }
  }
}

# *****************
# CType: text
# *****************
tt_content.text {
	20.wrap = <div class="csc-text">|</div>
}

plugin.tt_content._CSS_DEFAULT_STYLE (
		.layout-0 {font-size:100%;}
		.layout-1 {font-size:95%;}
		.layout-2 {font-size:110%;}
		.layout-3 {font-size:120%;}
		
		.content_border .csc-text A, .content_border csc-textpic A { color:#009ee0; }
		.content_border .csc-text A:hover, .content_border csc-textpic A:hover { text-decoration:none;opacity:0.8; }

      .csc-wichtig {background:#fee;border:solid #000;border-width:1px 1px 0 0;}
      .csc-linksfliessend {float:left;width:auto;}
      .csc-linksfliessend.layout-1 P, .csc-linksfliessend.layout-1 DIV FORM, .csc-linksfliessend.layout-1 DIV DIV {padding:0 2px;}
      .csc-rechtsfliessend {float:right;width:auto;}
      .csc-rechtsfliessend.layout-1 P {padding:0 2px;}
      .csc-endefliessend {clear:both;}
      .csc-unsichtbar {display:none;}
      div.csc-frame-indent6633 {float:left;width:66%;padding:0px;}
      div.csc-frame-indent3366 {float:left;width:33%;padding:0px;}
      div.csc-frame-indent3366 p.bodytext {padding:0 0 0 13px;font-size:95%;color: rgb(102, 102, 102);letter-spacing: 0;}
	  /* native tt_content elements */
      .csc-frame-frame1 {border:1px solid #555555;padding:3px;margin:2px;background:#E0E0E0;}
      .csc-frame-frame2 {border:0px solid #555555;padding:3px;margin:2px;background:#FFFF99;}
      .csc-frame-indent {float:left;width:auto;padding-right:5px;}
      .csc-frame-leftfloat{float:left;width:auto;padding:0 4px 0 4px;}
      .csc-frame-leftclear{clear:left;width:auto;}
      .csc-frame-rulerBefore{border-top:1px solid black;;padding-top:5px;}
      .csc-frame-rulerAfter{border-bottom:1px solid black;padding-bottom:5px;}
)
 
