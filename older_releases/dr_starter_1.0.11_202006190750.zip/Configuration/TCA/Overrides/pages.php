<?php
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/TSconfig_all.txt',
        'Eigener Style, alle überflüssige Eingabefelder ausblenden.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_defaults.txt',
        'Nichts ausblenden aber eigener Style, Listen und Beschriftungen.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_meta.txt',
        'Ausblenden: Metadaten, Sprache, Kategorien und Hinweise.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_date.txt',
        'Ausblenden: Ablaufdatum und Cache-verhalten.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_admin.txt',
        'Ausblenden: Admin Felder.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_title.txt',
        'Ausblenden: Titel vereinfachen in Inhalte und Seite.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_users.txt',
        'Ausblenden Users: Persönliche Daten und Hinweise.'
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_motion.txt',
        'Ausblenden: Ändernde Bilder im Header. '
);


\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        'dr_starter',
        'Configuration/PageTSConfig/detailed/TSconfig_reset.txt',
        'Alles wieder herstellen'
);

