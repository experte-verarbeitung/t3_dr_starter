function drstarter_onLoad( breakpoint ) {
    $('.frame-type-menu_section A').on('click',function() { 
        if ( $(window).width() < breakpoint ) drstarter_clickOnNavi( this ); 
    });
    if( $(document).width() < breakpoint ) drstarter_scrollToAnchor();

    fitStyleToWindowSize( breakpoint );
    window.onresize = function(event) { fitStyleToWindowSize( breakpoint ); }
    $(window).scroll(function () { fitStyleToWindowSize( breakpoint ); });
}

function drstarter_clickOnNavi(link) {
    // works only on same page without reload. only for small devices
    window.location.href =  $( link ).prop('href') ;
            var headerHeight = $('#header_container').outerHeight();
//             var roundedTop =  Math.round( 10 + headerHeight );
            var topPosition = $(window.location.hash).offset().top - headerHeight;
            if( topPosition < 1 ) topPosition = 0;
            $("body,html").animate({
                scrollTop: topPosition
            }, 550);
}

function drstarter_scrollToAnchor() { 
    // only for small devices
        if(  $(window.location.hash).offset() ){
            var headerHeight = $('#header_container').outerHeight();
            var newOffset = $(window.location.hash).offset();
            var topPosition = newOffset.top - headerHeight;
            if( topPosition < 1 ) topPosition = 0;
            $("body,html").animate({
                scrollTop: topPosition
            }, 550);
        }
}

function fitStyleToWindowSize( breakpoint ) {
    if ( $(window).width() >= breakpoint ) { // large window
        $('#homebut_container').fadeIn(0);
    }else{ // small device
        if( $(document).width() < breakpoint ) drstarter_chooseLogo();
    }
}
function drstarter_chooseLogo() {
    // only for small devices
    if( $(this).scrollTop() > $('#header_container').outerHeight() ){
        // scrolled until end of Head
        $('#homebut_container').fadeOut(0);
    }else{
        // no scrolled much
        $('#homebut_container').fadeIn(0);
    }
}

function displayMenu( show ) {
    if ( show ) { 
        $('.info_clicknavi').fadeIn(80);
        displayMnu_fullSize(); 
        if( $('NAV.navigation_full').outerHeight() >$(window).height() ){ 
            displayMnu_optSize();
        }
    } else {
        $('.info_clicknavi').fadeOut(80);
    }
}
function displayMnu_fullSize() {
            $('NAV.navigation_full').css( 'height', '' ); 
            $('NAV.navigation_full').css( 'overflow-y', '' ); 
            $('NAV.navigation_full').css( 'margin-top', '0px' ); 
}
function displayMnu_optSize() {
            $('NAV.navigation_full').css( 'height', Math.round($(window).height()-30) +'px' ); 
            $('NAV.navigation_full').css( 'overflow-y', 'scroll' ); 
            $('NAV.navigation_full').css( 'margin-top', '12px' ); 
}

function anfang() {
	$("body,html").animate({
		scrollTop: 0,
		scrollLeft: 0
	}, 550);
}

function ende() {
	$("body,html").animate({
		scrollTop: $(document).height() + $(window).height(),
		scrollLeft: 8
	}, 550);
}
