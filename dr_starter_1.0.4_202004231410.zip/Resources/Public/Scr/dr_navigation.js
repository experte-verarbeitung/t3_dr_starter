function fitStyleToWindowSize( breakpoint ) {
		viewportwidth = $(window).width();
		if (viewportwidth > breakpoint ) {
//  			$('.info_clicknavi').fadeOut(0);
		}
}

$(document).ready(function(){
	fitStyleToWindowSize( 635 );
	window.onresize = function(event) { fitStyleToWindowSize( 635 ); }
   
//     $('.info_upward').fadeOut(300);
//     $('.info_username').fadeIn(300);

	$(function () {
		$(window).scroll(function () {
            // Wenn 150 Pixel gescrolled wurde
            var has_scrolled = $(this).scrollTop() > 150;
//             if( has_scrolled == false ) displayMenu( has_scrolled );
		});
	});	
	
});

function displayMenu( show ) {
    if ( show ) { 
        $('.info_clicknavi').fadeIn(80);
    } else {
        $('.info_clicknavi').fadeOut(80);
    }
}

function anfang() {
	$("body,html").animate({
		scrollTop: 0,
		scrollLeft: 0
	}, 550);
}

function ende() {
	$("body,html").animate({
		scrollTop: $(document).height() + $(window).height(),
		scrollLeft: 8
	}, 550);
}
