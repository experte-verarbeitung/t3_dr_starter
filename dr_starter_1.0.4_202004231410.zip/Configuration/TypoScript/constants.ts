# customcategory=sfgz_design=DR Starter
# customsubcategory=a_grund=Grundeinstellungen
# customsubcategory=bb_titles=Titlei
# customsubcategory=bc_design=Design
# customsubcategory=c_special2Content=Spezielle Inhalte
# customsubcategory=d_javascript=JavaScript

plugin.dr_starter {
    settings {
        # cat=sfgz_design/a_grund/a; type=text; label=baseURL:Basis URL mit Protokoll zB. http://my.example.com/path2typo3/
        baseURL = https://polygrafie.sfgz.ch/datenbanken/
        # cat=sfgz_design/a_grund/b; type=text; label=absRefPrefix:Wenn gesetzt, wird der Pfadteil allen mit TypoScript erzeugten Links vorangestellt. Z.B.:  /path2typo3/
        absRefPrefix = /datenbanken/
        # cat=sfgz_design/bb_titles/2; type=text; label=Browser-Titel:Website-Titel im Rahmen des Browsers.
        browsertitle = Colormixture
        # cat=sfgz_design/bb_titles/4; type=text; label=Website-Titel:Website-Titel auf Seite.
        sitetitle = Colormixture - Farbmischung
        # cat=sfgz_design/bb_titles/6; type=text; label=Small Dev Website-Titel:Website-Titel auf Smartphone Seite.
        siteshorttitle = Colormixture
        # cat=sfgz_design/bb_titles/8; type=text; label=Website-Subtitel:Kleiner Subtitel neben Website-Titel auf Seite.
        sitesubtitle = Additive und Subtraktiv
        # cat=sfgz_design/bc_design/1; type=int; label=Maximale Breite:Maximale Breite der Website
        maxwidth = 1500
        # cat=sfgz_design/bc_design/2; type=int; label=Minimale Breite:Minimale Breite der Website
        minwidth = 300
        # cat=sfgz_design/bc_design/3; type=int; label=Logo Breite:Breite des logos in Pixel
        logowidth = 184
        # cat=sfgz_design/c_special2Content/6; type=int; label=permacontent:Uid des Content Elements in der Sidebar.
        permacontent = 0
        # cat=sfgz_design/c_special2Content/7; type=int; label=CSS content:Uid des Content Elements mit CSS Code für Header.
        css_content = 0
        # cat=sfgz_design/c_special2Content/8; type=int; label=Js Content:Uid des Content Elements mit JS Code für Header.
        js_content = 0
        # cat=sfgz_design/d_javascript/1; type=boolean; label=JQuery laden: Markierung aufheben wenn JQuery anderweitig geladen wird
        loadjquery=1
        # cat=sfgz_design/a_grund/c; type=boolean; label=Debug:Zeigt Layout-Informationen im Footer
        debug = 0
    
        # cat=sfgz_design/bc_design/4; type=options[Helvetica,Antaro,Cloudy,Comics]; label= Schrift Titel 
        font_title = Cloudy
        # cat=sfgz_design/bc_design/5; type=options[Helvetica,Antaro,Cloudy,Comics]; label= Schrift Inhalt 
        font_content = Comics
        # cat=sfgz_design/bc_design/6; type=options[Helvetica,Antaro,Cloudy,Comics]; label= Schrift Seiten Sub-Header
        font_subheader = Comics
        # cat=sfgz_design/bc_design/7; type=options[Helvetica,Antaro,Cloudy,Comics]; label= Schrift Info und verstecktes Menu
        font_infos = Helvetica
    }
}


