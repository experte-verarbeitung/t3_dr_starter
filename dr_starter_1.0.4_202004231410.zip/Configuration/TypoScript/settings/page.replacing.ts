## make some variables accessable for FE: vorname, nachname, email, fachbereich, coming-from-page
lib.replacements = COA
lib.replacements {

  10 {
    search = #vorname#
    replace.cObject = COA_INT
    replace.cObject.1 = TEXT
    replace.cObject.1 {
      data = TSFE:fe_user|user|first_name
      insertData=1
    }
  }
  
  20 < .10
  20.search = #nachname#
  20.replace.cObject.1.data = TSFE:fe_user|user|last_name

  22 < .10
  22.search = #user#
  22.replace.cObject.1.data = TSFE:fe_user|user|username
  
  30 {
    search = #datum#
    replace.cObject = COA_INT
    replace.cObject.1 = TEXT
    replace.cObject.1 {
        data = date:U
        strftime = %d-%m-%Y
    }
  }
  32 < .30
  32.search = #jahr#
  32.replace.cObject.1.strftime = %Y
  
  70 {
    search = #baseurl#
    replace.cObject = TEXT
    replace.cObject.value = {$plugin.dr_starter.settings.baseURL}
  }

}

# Forms redirect
lib.replacements {
  90 < .10
  90 {
    search = _TO-PAGE_
	replace.cObject = COA_INT
	replace.cObject.10 = TEXT
    replace.cObject.10.value = 
	replace.cObject.20 = TEXT
  }
  95 < .90
  95.search = _PAGE_
  95.replace.cObject.20.data = GP:page
}

[globalVar = GP:page>0]
lib.replacements.90 {
	replace.cObject.10.value = ?id=
	replace.cObject.20.data = GP:page
}
[global]

## lib.permacontent
lib.permacontent = COA
lib.permacontent {
      wrap = |
      
      10 = RECORDS
      10 {
	  	  tables = tt_content
	  	  source = {$plugin.dr_starter.settings.permacontent}
      }
}

## page.css_content
page.headerData.13 = RECORDS
page.headerData.13 {
   source = {$plugin.dr_starter.settings.css_content}
   tables = tt_content
   conf.tt_content = COA
   conf.tt_content {
      20 = TEXT
      20.stdWrap.field = bodytext
	  20.wrap (
<style>|</style>
	  )
   }
}

## page.js_content
page.headerData.14 = RECORDS
page.headerData.14 {
   source = {$plugin.dr_starter.settings.js_content}
   tables = tt_content
   conf.tt_content = COA
   conf.tt_content {
      20 = TEXT
      20.stdWrap.field = bodytext
	  20.wrap (
<script>|</script>
	  )
   }
}

lib.permacontent.stdWrap.replacement < lib.replacements
page.headerData.13.conf.tt_content.stdWrap.replacement < lib.replacements

page.10.variables.content_main.stdWrap.replacement < lib.replacements
page.10.variables.content_column_1.stdWrap.replacement < lib.replacements
page.10.variables.content_column_2.stdWrap.replacement < lib.replacements
page.10.variables.content_border.stdWrap.replacement < lib.replacements
