plugin.tx_dr_starter_css._CSS_DEFAULT_STYLE (
    /* Override font-families if given in plugin-constants from template. */
    #container, #blank_container {
        font-family: {$plugin.dr_starter.settings.font_content};
    }
    
    H1,H2,H3,H4,H5 , .navigation_top , .navigation_sub {
        font-family: {$plugin.dr_starter.settings.font_title};
    }
    
    .navigation_subtitle H1 {
        font-family: {$plugin.dr_starter.settings.font_subheader};
        margin:0 0 3px 0;
    }

    #lightbox,  .drstarter_footer , #fixlogo_container {
        font-family: {$plugin.dr_starter.settings.font_infos};
    }
    
    /* content sizes and position */
    #blank_container .grid_element {
        width:100%;
    }
    .third, .double, .half, .fifty {
        float:left;
    }
    
    .third {
        width:33.33%;
    }
    .third.padded {
        width:calc(33.33% - 4px);
    }
    
    .double {
        width:66%;
    }
    .double.padded {
        width:calc(66% - 2px);
    }
    
    .half, .fifty {
        width:50%;
    }
    .half.padded {
        width:calc(50% - 4px);
    }
    .fifty.padded {
        width:calc(50% - 4px);
    }
    .page-layout-0 .fifty.padded {
        width:50%;
        margin:0;
        border:0;
    }
    
    #container, #blank_container {
        max-width:{$plugin.dr_starter.settings.maxwidth}px;
        min-width:{$plugin.dr_starter.settings.minwidth}px;
    }
    #container DIV.inner_container, .drstarter_footer  {
        margin-left:{$plugin.dr_starter.settings.logowidth}px;
    }
    #navigation_container {
        margin-left:{$plugin.dr_starter.settings.logowidth}px;
         /* min-height:{$plugin.dr_starter.settings.logowidth}px; */
    }
    #fixlogo_container , #homebut_container {
        width:{$plugin.dr_starter.settings.logowidth}px;
    }   
    #visible_img , #invisible_img , #homebut_container , info_clicknavi , info_upward {
        width:calc( {$plugin.dr_starter.settings.logowidth}px -11px );
    } 
    .grid_element {
        min-width:{$plugin.dr_starter.settings.minwidth}px;
    }
    
/* maxwidth = ca 1500 */
@media screen and ( max-width:calc( {$plugin.dr_starter.settings.maxwidth}px - 10px ) ) {
    
        DIV.be_layout_pagets__2 .third.pos-right {
            width:100%;
        }
        
        .grid_element.third.padded,
        .grid_element.half.padded,
        .grid_element.double.padded,
        .grid_element.fifty.padded { 
            width:calc(50% - 4px);
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }

        .grid_element.half,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.third { 
            width:50%;
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }

        #container DIV.inner_container, 
        #navigation_container, .drstarter_footer, 
        #homebut_container {
            margin-left:105px;
        }

        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:100px;
        }
}

    
/* 3 x min width = ca 900 */
@media screen and ( max-width:calc( 50px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px) ) {
        #container DIV.inner_container, .drstarter_footer ,
        #navigation_container, 
        #homebut_container {
            margin-left:55px;
        }

        #homebut_container,
        #fixlogo_container,
        .info_upward , 
        #visible_img , 
        #invisible_img {
            width:50px;
        }
        
        .grid_element.third.padded,
        .grid_element.half.padded,
        .grid_element.double.padded,
        .grid_element.fifty.padded,
        .grid_element.third,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half {
            width:100%;
            min-width:calc( {$plugin.dr_starter.settings.minwidth}px );
        }
        .grid_element.mob_full {
            width:100%;
            min-width:calc( {$plugin.dr_starter.settings.minwidth}px );
        }
}
/* 2 x min width = ca 600 */
@media screen and ( max-width:calc( 50px + {$plugin.dr_starter.settings.minwidth}px + {$plugin.dr_starter.settings.minwidth}px ) ) {
        .grid_element,
        .grid_element.third,
        .grid_element.half,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half {
            width:100%;
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }
}
/* 1 x min width = ca 300 */
@media screen and ( max-width:calc( 50px + {$plugin.dr_starter.settings.minwidth}px ) ) {
        .grid_element,
        .grid_element.third,
        .grid_element.half,
        .grid_element.double,
        .grid_element.fifty,
        .grid_element.half {
            width:100%;
            min-width:{$plugin.dr_starter.settings.minwidth}px;
        }
}


)
