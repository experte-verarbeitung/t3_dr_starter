## + lib.info.ts

## contains:
## lib.info_baseURL
## lib.info_pagelayout
## info_backend_layout

## lib.info_sitetitle_web info_sitetitle_web
## lib.info_sitetitle_mob info_sitetitle_mob
## lib.info_pagetitle info_pagetitle
## lib.info_titles_screen info_titles_screen
## lib.info_titles_print info_titles_print

lib.info_baseURL = TEXT
lib.info_baseURL.insertData = 1
lib.info_baseURL.value = {$plugin.dr_starter.settings.baseURL}

lib.info_debug = TEXT
lib.info_debug.insertData = 1
lib.info_debug.value = {$plugin.dr_starter.settings.debug}

lib.info_datum = TEXT
lib.info_datum.insertData = 1
lib.info_datum {
        data = date:U
        strftime = %d-%m-%Y
}

lib.info_unixzeit = TEXT
lib.info_unixzeit
lib.info_unixzeit {
        insertData = 1
        data = date:U
}

## info_pagelayout
lib.info_pagelayout = TEXT
lib.info_pagelayout.insertData = 1
lib.info_pagelayout.value = {page:layout}

## info_backend_layout
lib.info_backend_layout = TEXT
lib.info_backend_layout.insertData = 1
lib.info_backend_layout.value = {page:backend_layout}


## lib.info_sitetitle_web
lib.info_sitetitle_web = COA_INT
lib.info_sitetitle_web {
    stdWrap.wrap = <H1 class="pagetitle">|</H1>
    10 = TEXT
    10 {
        insertData = 1
        noTrimWrap = | | |
        value = {$plugin.dr_starter.settings.sitetitle}
    }
    20 < .10
    20 {
        noTrimWrap = | <span style="font-size:0.5em;"> | </span> |
        value = {$plugin.dr_starter.settings.sitesubtitle}
    }
}

## lib.info_sitetitle_mob
lib.info_sitetitle_mob < lib.info_sitetitle_web
lib.info_sitetitle_mob.10.value = {$plugin.dr_starter.settings.siteshorttitle}
lib.info_sitetitle_mob.stdWrap.wrap = <H1 class="mob_pagetitle">|</H1>
lib.info_sitetitle_mob.20 >

## info_pagetitle
lib.info_pagetitle = COA_INT
lib.info_pagetitle {
	wrap = <H2 class="info_pagetitle page-title ">|</H2>
    10 = TEXT
	10.insertData = 1
	10.data = page:title
}

## Title info_titles_screen
lib.info_titles_screen = COA_INT
lib.info_titles_screen {
    
    wrap = <div class="navigation_subtitle">|</div>
    # wenn kein subtitle dann anders wrappen
    wrap.override.if.isFalse.data = page:subtitle
    wrap.override = <div style="display:none;">|</div>
    
    # aktueller Seitentitel aus Tabelle page (ausgeblendet mit 10.wrap )
    10 = COA
    10.wrap = <div style="display:none;">|</div>
    10.1 = TEXT
    10.1 {
        insertData = 1
        value = {page:title}
        value.insertData = 1
        noTrimWrap = | |: |
        # wenn kein subtitle dann ohne doppelpunkt wrappen
        noTrimWrap.override.if.value.data = page:subtitle
        noTrimWrap.override.if.equals = .
        noTrimWrap.override = | | |
    }
    
    # aktueller Seiten-Untertitel aus Tabelle page
    15 = TEXT
    15 {
        insertData = 1
        value = {page:subtitle}
        noTrimWrap = | <H1>|</H1> |
        # wenn kein subtitle dann verstecken
        noTrimWrap.override.if.value.data = page:subtitle
        noTrimWrap.override.if.equals = .
        noTrimWrap.override = |<div style="display:none;">|</div>|
    }
    
}

## Title info_titles_print
lib.info_titles_print = COA
lib.info_titles_print {
    
    wrap = <div class="info_titles_print site-title"><H1>|</H1></div>
    
    5 = TEXT
    5 {
        value = {$plugin.dr_starter.settings.sitetitle}
    }
    
    10 = TEXT
    10 {
        value = {$plugin.dr_starter.settings.sitesubtitle}
        noTrimWrap = |<span class="smallhint"> |</span>|
    }
    
}
