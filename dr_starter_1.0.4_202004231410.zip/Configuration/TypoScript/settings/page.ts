# enable admin user to clear all system caches without to enter install tool (since 6.2):
options.clearCache.system = 1
options.clearCache.all = 1

config {
    baseURL = {$plugin.dr_starter.settings.baseURL}
    absRefPrefix = {$plugin.dr_starter.settings.absRefPrefix}
    doctype = html5
    metaCharset = utf-8

    language = de
    locale_all = de_DE.utf8
    htmlTag_langKey = de-CH
#    prefixLocalAnchors = all
    prefixLocalAnchors = 0

    spamProtectEmailAddresses = 2
    spamProtectEmailAddresses_atSubst = <img src="/typo3conf/ext/dr_starter/Resources/Public/Img/Web/at_10.png" alt="[at]" />
    spamProtectEmailAddresses_lastDotSubst = <img src="/typo3conf/ext/dr_starter/Resources/Public/Img/Web/dot.png" alt="." />

    no_cache = 0
    debug = 0
    tx_extbase.mvc.callDefaultActionIfActionCantBeResolved = 0
    
    # bring back old error-hints in FE instead of 'Oops, an error occured...'
    contentObjectExceptionHandler = 0
    
    # admPanel overwrite in userTS: page.config.admPanel = 0
    admPanel = 0
    # frontend_editing = 0
    
    # indexed search
    index_enable = 1 
    index_externals = 1 
}

# use swiss Date in Plugin-Header 
lib.stdheader.40.10.strftime = %d.%m.%Y

page = PAGE
page.typeNum = 0
page.shortcutIcon = typo3conf/ext/dr_starter/Resources/Public/Img/Web/favicon.ico

page.10 = FLUIDTEMPLATE
page.10 {
    partialRootPath = EXT:dr_starter/Resources/Private/Partials/
    layoutRootPath = EXT:dr_starter/Resources/Private/Layouts/
    variables {
        content_main < styles.content.get
        content_main.select.where = colPos = 0
        content_column_1 < styles.content.get
        content_column_1.select.where = colPos = 1
        content_column_2 < styles.content.get
        content_column_2.select.where = colPos = 2
        content_border < styles.content.get
        content_border.select.where = colPos = 3
    }

    file.stdWrap.cObject = CASE
    file.stdWrap.cObject {
        
        # Die Backend Layout ID definiert das Frontend Template
        # sliden, falls Backend Layouts auf Unterseiten vererbt wurden.
        key.data = levelfield:-1, backend_layout, slide
        key.override.field = backend_layout

        # Standard Layout
        # Wird verwendet wenn keine spezielles Backend Layout definiert wurde.
        default = TEXT
        default.value = EXT:dr_starter/Resources/Private/Templates/sfgz_3_column_large.html

        # Wenn wir Backend Layouts über die Datenbank definieren, dann wird an dieser Stelle die ID des Datensatz stehen.
        # Da wir diese aber ins Page TSConfig auslagern, müssen wir der ID "pagets__" voranstellen.

        # Definition SfGZ oben 3 Spalten breit
        pagets__1 = TEXT
        pagets__1.value = EXT:dr_starter/Resources/Private/Templates/sfgz_3_column_large.html
        
        # Definition oben rechts 2 Spalten breit
        pagets__2 = TEXT
        pagets__2.value = EXT:dr_starter/Resources/Private/Templates/sfgz_2_column_right.html

        # Definition oben links 2 Spalten breit
        pagets__3 = TEXT
        pagets__3.value = EXT:dr_starter/Resources/Private/Templates/sfgz_2_column_left.html
        
        # Definition mit Sidebar und oben 2 Spalten breit 
        pagets__4 = TEXT
        pagets__4.value = EXT:dr_starter/Resources/Private/Templates/sfgz_4_column.html

        # Definition Popup
        pagets__5 = TEXT
        pagets__5.value = EXT:dr_starter/Resources/Private/Templates/sfgz_1_column_without_menu.html
    }
}

## include general CSS

page.includeCSS.dr_main = typo3conf/ext/dr_starter/Resources/Public/Css/dr_starter_main.css
page.includeCSS.dr_colors = typo3conf/ext/dr_starter/Resources/Public/Css/dr_starter_colors.css


## include JavaScript and jquery 
[globalVar = LIT:0<{$plugin.dr_starter.settings.loadjquery}]
		page.includeJS.jquery_a = https://code.jquery.com/jquery-3.4.1.js
		page.includeJS.jquery_m = https://code.jquery.com/jquery-3.4.1.min.js
		page.includeJS.jquery_uimin = https://code.jquery.com/ui/1.12.1/jquery-ui.min.js
[global]

## smove on-top movement with dr_navigation.js
page.includeJSFooter.sfgz_navi = typo3conf/ext/dr_starter/Resources/Public/Scr/dr_navigation.js


