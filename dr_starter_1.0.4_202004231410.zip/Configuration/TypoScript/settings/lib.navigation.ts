## + navigation.ts

## lib.navigation_top
## lib.navigation_sub
## lib.navigation_full
## lib.breadcrumb

lib.navigation_top = HMENU
lib.navigation_top.wrap = <nav class="navigation_top">|</nav>
lib.navigation_top {
            ### Erste Ebene ###
            1 = TMENU
            1 {
                wrap = <ul class="menu">|</ul>
                expAll = 1
                NO.wrapItemAndSub = <li class="menuitem normal">|</li> 
                NO.ATagParams.cObject = COA
                NO.ATagParams.cObject.10 = TEXT
                ACT < .NO
                ACT = 1
                ACT.ATagParams.cObject.10.value = onfocus="this.blur()"
                ACT.wrapItemAndSub = <li class="menuitem selected">|</li>
                ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
            }
}


## lib.navigation_sub
lib.navigation_sub = HMENU
lib.navigation_sub {
        wrap = <nav class="navigation_sub">|</nav>
        includeNotInMenu = 0
        entryLevel = 1
        1 = TMENU
        1 {
                expAll = 0
                wrap = <ul class="menu menu_1">|</ul>
                
                NO.wrapItemAndSub = <li class="menuitem normal">|</li>
                NO.ATagParams.cObject = COA
                NO.ATagParams.cObject.10 = TEXT
                NO.ATagParams.cObject.10.value = onfocus="this.blur()"
                
                ACT < .NO
                ACT = 1
                ACT = wrapItemAndSub = <li class="menuitem selected">|</li>
                ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
                
                CUR < .NO
                CUR = 1
                CUR.wrapItemAndSub = <li class="menuitem current">|</li>
                CUR.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
            
        }
        2 = TMENU
        2 {
            expAll = 0
                wrap = <ul class="menu menu_2">|</ul>
                NO.wrapItemAndSub = <li class="menuitem normal">|</li>
                ACT < .NO
                ACT.wrapItemAndSub = <li class="menuitem selected">|</li>
                ACT = 1
                CUR < .NO
                CUR.wrapItemAndSub = <li class="menuitem currrent">|</li>
                CUR = 1
        }

}

## lib.navigation_full
lib.navigation_full = HMENU
lib.navigation_full {
            wrap (
                <div class="hamburger" onclick="if($('.info_clicknavi').is(':visible')){ disp = false; }else{ disp = true; };displayMenu( disp );">
                    <span></span><span></span><span></span>
                </div>
                <div class="screen info_clicknavi">
                    <nav class="navigation_full">|</nav>
                </div>
            )
            includeNotInMenu = 0
            ### Erste Ebene ###
            1 = TMENU
            1 {
                entryLevel = 0
                wrap = <ul class="menu">|</ul>
                expAll = 1
                
                NO.wrapItemAndSub = <li class="menuitem normal">|</li> 
                NO.ATagParams.cObject = COA
                NO.ATagParams.cObject.10 = TEXT
                NO.ATagParams.cObject.10.value = onfocus="this.blur()"
                NO = 1
                
                ACT < .NO
                ACT = 1
                ACT.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
                ACT.wrapItemAndSub = <li class="menuitem selected">|</li>
                
                CUR < .ACT
                CUR.wrapItemAndSub = <li class="menuitem current">|</li>
                CUR.ATagParams.cObject.10.value = class="selected" onfocus="this.blur()"
            }
            ### weitere Ebenen ###
            2 < .1
            2.entryLevel = 1
            3 < .2
            3.entryLevel = 2
            4 < .2
            4.entryLevel = 3
}

# lib.breadcrumb
lib.breadcrumb = COA
lib.breadcrumb {
10 = HMENU
10 {
 special = rootline
 special.range = 0|-1
 1 = TMENU
     # no unneccessary scripting.
     1.noBlur = 1
     # Current item should be unlinked
     1.CUR = 1
     1.target = _self
     1.wrap = <div class="breadcrumb"> | </div>
     1.NO {
         stdWrap.field = title
         ATagTitle.field = nav_title // title
         linkWrap = ||*| >> |*|
         }
     # Current menu item is unlinked
     1.CUR {
         stdWrap.field = title
         linkWrap = ||*| >> |*|
         doNotLinkIt = 1
         }
    }
}

