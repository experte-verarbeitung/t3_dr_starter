<?php

/***************************************************************
 * Extension Manager/Repository config file for ext: "dr_design"
 *
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array(
	'title' => 'dr Starter. Webpage Basics.',
	'description' => 'Minimal affored files to create a Website. Theme dr 20120',
	'category' => 'module',
	'author' => 'Daniel Rueegg',
	'author_email' => 'colormixture@verarbeitung.ch',
	'state' => 'stable',
	'internal' => '',
	'uploadfolder' => '0',
	'createDirs' => '',
	'clearCacheOnLoad' => 0,
	'version' => '1.0.4',
	'constraints' => array(
		'depends' => array(
			'typo3' => '7.6.0-9.9.99',
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
);
